# Author: JosÃ© Moura
# Adapted from Java's implementation of Rui Pedro Paiva
# Teoria da Informacao, LEI, 2022

import sys
from huffmantree import HuffmanTree
import numpy as np

class GZIPHeader:
    ''' class for reading and storing GZIP header fields '''

    ID1 = ID2 = CM = FLG = XFL = OS = 0
    MTIME = []
    lenMTIME = 4
    mTime = 0

    # bits 0, 1, 2, 3 and 4, respectively (remaining 3 bits: reserved)
    FLG_FTEXT = FLG_FHCRC = FLG_FEXTRA = FLG_FNAME = FLG_FCOMMENT = 0   

    # FLG_FTEXT --> ignored (usually 0)
    # if FLG_FEXTRA == 1
    XLEN, extraField = [], []
    lenXLEN = 2

    # if FLG_FNAME == 1
    fName = ''  # ends when a byte with value 0 is read

    # if FLG_FCOMMENT == 1
    fComment = ''   # ends when a byte with value 0 is read
    
    # if FLG_HCRC == 1
    HCRC = []
        
    
    def read(self, f):
        ''' reads and processes the Huffman header from file. Returns 0 if no error, -1 otherwise '''

        # ID 1 and 2: fixed values
        self.ID1 = f.read(1)[0]  
        if self.ID1 != 0x1f: return -1 # error in the header
            
        self.ID2 = f.read(1)[0]
        if self.ID2 != 0x8b: return -1 # error in the header
    
        # CM - Compression Method: must be the value 8 for deflate
        self.CM = f.read(1)[0]
        if self.CM != 0x08: return -1 # error in the header
                
        # Flags
        self.FLG = f.read(1)[0]
        
        # MTIME
        self.MTIME = [0]*self.lenMTIME
        self.mTime = 0
        for i in range(self.lenMTIME):
            self.MTIME[i] = f.read(1)[0]
            self.mTime += self.MTIME[i] << (8 * i)                 
                    
        # XFL (not processed...)
        self.XFL = f.read(1)[0]
        
        # OS (not processed...)
        self.OS = f.read(1)[0]
        
        # --- Check Flags
        self.FLG_FTEXT = self.FLG & 0x01
        self.FLG_FHCRC = (self.FLG & 0x02) >> 1
        self.FLG_FEXTRA = (self.FLG & 0x04) >> 2
        self.FLG_FNAME = (self.FLG & 0x08) >> 3
        self.FLG_FCOMMENT = (self.FLG & 0x10) >> 4
                
        # FLG_EXTRA
        if self.FLG_FEXTRA == 1:
            # read 2 bytes XLEN + XLEN bytes de extra field
            # 1st byte: LSB, 2nd: MSB
            self.XLEN = [0]*self.lenXLEN
            self.XLEN[0] = f.read(1)[0]
            self.XLEN[1] = f.read(1)[0]
            self.xlen = self.XLEN[1] << 8 + self.XLEN[0]
            
            # read extraField and ignore its values
            self.extraField = f.read(self.xlen)
        
        def read_str_until_0(f):
            s = ''
            while True:
                c = f.read(1)[0]
                if c == 0: 
                    return s
                s += chr(c)
        
        # FLG_FNAME
        if self.FLG_FNAME == 1:
            self.fName = read_str_until_0(f)
        
        # FLG_FCOMMENT
        if self.FLG_FCOMMENT == 1:
            self.fComment = read_str_until_0(f)
        
        # FLG_FHCRC (not processed...)
        if self.FLG_FHCRC == 1:
            self.HCRC = f.read(2)
            
        return 0


class GZIP:
    ''' class for GZIP decompressing file (if compressed with deflate) '''

    gzh = None
    gzFile = ''
    fileSize = origFileSize = -1
    numBlocks = 0
    f = None

    bits_buffer = 0
    available_bits = 0        

    
    def __init__(self, filename):
        self.gzFile = filename
        self.f = open(filename, 'rb')
        self.f.seek(0,2)
        self.fileSize = self.f.tell()
        self.f.seek(0)

        
    

#1
    def readblockformat(self):
        return self.readBits(5), self.readBits(5), self.readBits(4)

#2
    def store_base_code_len(self, HCLEN, order):
        symbol_lengths = list(np.zeros(len(order)).astype("uint8"))
        for i in range(HCLEN + 4):
            symbol_lengths[order[i]] = self.readBits(3)
        return symbol_lengths
#3
    def para_huffman(self, symbol_lengths):
        MAX_BITS = np.max(symbol_lengths)
        bl_count = np.bincount(symbol_lengths, minlength=np.array(symbol_lengths).max())
        bl_count[0] = 0 #não há simbolos codificados com zero bits
    
        next_code = np.zeros_like(bl_count, dtype = np.uint16)
        code = 0
    
        for numbits in range(1, MAX_BITS + 1):
            code = (code + bl_count[numbits-1]) << 1
            next_code[numbits] = code
            
        tree_code = np.empty(len(symbol_lengths), dtype = object)
        
        for i in range(len(symbol_lengths)):
            if symbol_lengths[i] != 0:
                tree_code[i] = bin(next_code[symbol_lengths[i]])[2:].zfill(symbol_lengths[i])#Retirar o "0b"
                next_code[symbol_lengths[i]] += 1
        tree = HuffmanTree()
        for i in range(len(tree_code)):
            if tree_code[i] != None:
                tree.addNode(tree_code[i], i, verbose = True)
        return tree
    
#4 & 5                  
    def store_code_lengths(self, size, tree_lencode, len_alphabet):
        
        arraycodigos = np.empty(size, dtype = np.uint8)
        cursymbol = 0
        
        num = 0
        while cursymbol < size:
            direction = str(self.readBits(1))
            pos = tree_lencode.nextNode(direction)
            if pos == -1:
                print("Erro na árvore (nonexistent Node)...")
                return -1
            if pos != -2:
                num = len_alphabet[pos]
                if num <= 15:
                    arraycodigos[cursymbol] = num
                    previouscomp = num  #Variável que guarda o último literal a ser inserido, útil no caso de num == 16
                    cursymbol += 1
                    tree_lencode.resetCurNode()
                    
                elif num == 16:
                    previous_copies = 3 + self.readBits(2)
                    arraycodigos[cursymbol : cursymbol + previous_copies] = previouscomp
                    cursymbol += previous_copies
                    tree_lencode.resetCurNode()
                elif num == 17:
                    repetitions = 3 + self.readBits(3)
                    arraycodigos[cursymbol : cursymbol + repetitions] = 0
                    cursymbol += repetitions
                    tree_lencode.resetCurNode()
                
                elif num == 18:
                    repetitions = 11 + self.readBits(7)
                    arraycodigos[cursymbol : cursymbol + repetitions] = 0
                    cursymbol += repetitions
                    tree_lencode.resetCurNode()
        return arraycodigos


#7
    def LZ77(self, dist_tree, lit_tree):
        arr = np.array([])#Array a retornar com valores associados à informação descomprimida
        comp = 0 #Número de carateres a copiar
        comp_found = False #Indicador de que se tem um comprimento e falta obter a distância 
        while 1:
            pos = -2
            #Enquanto não se tem o valor de comprimento, percorre-se a árvore de literais/comprimentos
            while not comp_found and pos == -2:
                pos = lit_tree.nextNode(str(self.readBits(1)))
            #Quando se tem um comprimento, pesquisa-se a distância correspondente
            while comp_found and pos == -2:
                pos = dist_tree.nextNode(str(self.readBits(1)))
            if pos == 256:
                return arr
            if pos == -1:
                print("Erro ao percorrer a árvore")
                return -1
            if pos < 256 and not comp_found:
                arr = np.append(arr, pos)#Adiciona literal
                lit_tree.resetCurNode()
            elif pos > 256 and not comp_found:
                comp = self.get_comp(pos)
                comp_found = True
                lit_tree.resetCurNode()
            else:
                #Caso se obtenha um par comprimento, distância
                comp_found = False#Preparar para a proxima iteração (voltar à pesquisa na árvore de literais)
                dist = self.get_dist(pos)
                aux = arr[-dist:]#Redução do array a retornar com a informação relevante a copiar 
                for i in range(comp):
                   arr = np.append(arr, aux[i % dist])#Se comp > dist, o indice do numero a copiar deve voltar ao zero e continuar a percorrer o array auxiliar
                dist_tree.resetCurNode()



    def get_comp(self, lit_code):
        numBits = (lit_code - 261) >> 2
        if numBits < 0:
            numBits = 0
        if numBits == 6:
            return 258
        if numBits == 0:
            return 3 + (lit_code - 257)
        inf = 3
        pot = (lit_code - 257) >> 2 # divisão por 4
        res = (lit_code - 257) % 4 # resto
        inf += 2**(pot + 1) + 2**(numBits) * res
        return inf + self.readBits(numBits)
    

    def get_dist(self, dist_code):
        inf, sup = 0, 0
        incremento= 0
        for i in range(dist_code + 1):
            incremento = (i - 2) // 2
            if i < 4: 
                incremento = 0
            inf = sup + 1
            sup = inf + 2**incremento - 1
        return inf + self.readBits(incremento)



    def decompress(self):
        ''' main function for decompressing the gzip file with deflate algorithm '''
        
        numBlocks = 0

        # get original file size: size of file before compression
        origFileSize = self.getOrigFileSize()
        print(origFileSize)
        
        # read GZIP header
        error = self.getHeader()
        if error != 0:
            print('Formato invalido!')
            return
        
        # show filename read from GZIP header
        print(self.gzh.fName)
        
        f = open(self.gzh.fName, 'wb')        # MAIN LOOP - decode block by block
        BFINAL = 0    
        while not BFINAL == 1:    
            
            BFINAL = self.readBits(1)
                            
            BTYPE = self.readBits(2)                    
            if BTYPE != 2:
                print('Error: Block %d not coded with Huffman Dynamic coding' % (numBlocks+1))
                return
            else:
                #1
                print("-------------------------------------PONTO 1-------------------------------------")
                HLIT, HDIST, HCLEN = self.readblockformat()
                print(HLIT, HDIST, HCLEN)
                #2
                print("-------------------------------------PONTO 2-------------------------------------")
                order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]
                symbol_lengths = self.store_base_code_len(HCLEN, order)
                print(symbol_lengths)
                #3
                print("-------------------------------------PONTO 3-------------------------------------")
                tree_lencodes = self.para_huffman(np.array(symbol_lengths))
                #4
                print("-------------------------------------PONTO 4-------------------------------------")
                lits = self.store_code_lengths(HLIT + 257, tree_lencodes, np.arange(len(symbol_lengths)))
                print(lits)
                #5
                print("-------------------------------------PONTO 5-------------------------------------")
                dists = self.store_code_lengths(HDIST + 1, tree_lencodes, np.arange(len(symbol_lengths)))
                print(dists)
                #6
                print("-------------------------------------PONTO 6-------------------------------------")
                print("LITERAIS/COMPRIMENTOS:")
                lit_tree = self.para_huffman(lits)
                print("DISTÂNCIAS")
                dist_tree = self.para_huffman(dists)
                #7
                print("-------------------------------------PONTO 7-------------------------------------")
                output_stream = self.LZ77(dist_tree, lit_tree).astype(np.uint8)
                print(output_stream)
                #8
                f.write(bytes(output_stream))
                                                                                                    
            # update number of blocks read
            numBlocks += 1
        f.close()
        
    
        
        # close file            
        
        self.f.close()    
        print("End: %d block(s) analyzed." % numBlocks)

        
    def getOrigFileSize(self):
        ''' reads file size of original file (before compression) - ISIZE '''
        
        # saves current position of file pointer
        fp = self.f.tell()
        
        # jumps to end-4 position
        self.f.seek(self.fileSize-4)
        
        # reads the last 4 bytes (LITTLE ENDIAN)
        sz = 0
        for i in range(4): 
            sz += self.f.read(1)[0] << (8*i)
        
        # restores file pointer to its original position
        self.f.seek(fp)
        
        return sz        
    

    
    def getHeader(self):  
        ''' reads GZIP header'''

        self.gzh = GZIPHeader()
        header_error = self.gzh.read(self.f)
        return header_error
        

    def readBits(self, n, keep=False):
        ''' reads n bits from bits_buffer. if keep = True, leaves bits in the buffer for future accesses '''

        while n > self.available_bits:
            self.bits_buffer = self.f.read(1)[0] << self.available_bits | self.bits_buffer
            self.available_bits += 8
        
        mask = (2**n)-1
        value = self.bits_buffer & mask

        if not keep:
            self.bits_buffer >>= n
            self.available_bits -= n

        return value

                


if __name__ == '__main__':

    # gets filename from command line if provided
    fileName = "FAQ.txt.gz"
    if len(sys.argv) > 1:
        fileName = sys.argv[1]            

    # decompress file
    gz = GZIP(fileName)
    gz.decompress()
