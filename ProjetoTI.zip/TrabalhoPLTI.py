# -*- coding: utf-8 -*-
'''
Cláudio Manuel Gomes Catarino (2022224320)
Luís Miguel Ferreira Vaz (2022214707)
José Afonso da Silva Domingues de Moura (2021273987)
'''
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import huffmancodec as huffc

#4
def contaOcorrencias(coluna, A):
    return np.bincount(coluna, minlength=A.size)

#5
def retiraZeros(arrayCont, alfabeto):#Recebe o array após a contagem de ocorrências de cada classe e retorna um conjunto de pares ordenados com valores e ocorrencias
        array = arrayCont[arrayCont.nonzero()]
        novoalfabeto = alfabeto[arrayCont.nonzero()]
        return np.column_stack((novoalfabeto, array))
        
def desenharGrafico(array, varNames, i):
    plt.figure(figsize=(15,5))
    plt.subplot(111)
    plt.bar(range(len(array[:,0])), array[:,1], color = 'red') #cria o eixo com os  valores do alfabeto
    plt.xticks(range(len(array[:,0])), array[:,0], rotation = 90, fontsize= 10)  #ajusta os valores do eixos aos valores dos arrays
    plt.xlabel(varNames[i])
    plt.ylabel('count') 
    plt.show()

def representa(matrix, alfabeto, varNames):
    #Supondo que a matrix não é vazia
    for i in range(len(matrix[0])):
        array = contaOcorrencias(matrix[:,i],alfabeto)
        array = retiraZeros(array, alfabeto)
        desenharGrafico(array, varNames, i)

#6
def binning(coluna, agrupamento, A):
    arraycont = contaOcorrencias(coluna, A)
    for i in range(0, len(arraycont), agrupamento):
        max_idx = np.argmax(arraycont[i:i+agrupamento])
        sub = A[i + max_idx]
        for j in range(len(coluna)):
            if(i + agrupamento >= len(arraycont)):
                agrupamento = len(arraycont) - i - 1
            if A[i] <= coluna[j] < A[i + agrupamento]:
                coluna[j] = sub

#7
def mediaBitsVar(alfabeto, coluna): 
    array = retiraZeros(contaOcorrencias(coluna, alfabeto), alfabeto)
    probs = array[:,1]/len(coluna)
    return -np.sum((probs)*np.log2(probs))

def mediaBitsTotal(alfabeto, matrix):
    array= matrix.flatten()
    return mediaBitsVar(alfabeto, array)

#8
def mediaBitsSimbolo(coluna):
    codec=huffc.HuffmanCodec.from_data(coluna)
    symbols, lengths=codec.get_code_len()
    aux, contadores = np.unique(coluna, return_counts = True)
    res = 0
    for i in range(len(aux)):
        res += lengths[np.where(symbols == aux[i])[0][0]] * contadores[i] /len(coluna)
    return res

def mediaBitsSimboloTotal(matrix):
    arr = matrix.flatten()
    return mediaBitsSimbolo(arr)

def varBitsSimbolo(coluna):
    codec=huffc.HuffmanCodec.from_data(coluna)
    symbols, lengths=codec.get_code_len()
    compmedio = mediaBitsSimbolo(coluna)
    aux, contadores = np.unique(coluna, return_counts = True)
    res = 0    
    for i in range(len(aux)):
        res += (math.pow(lengths[np.where(symbols == aux[i])[0][0]] - compmedio, 2) * contadores[i] )/len(coluna)
    return res

def varBitsSimboloTotal(matrix):
    arr = matrix.flatten()
    return varBitsSimbolo(arr)

#9
def Calcular_Pearson(matrix):
    num_columns = len(matrix[0])
    array_pearson = np.empty(num_columns - 1)
    for i in range(num_columns - 1):
        array_pearson[i] = np.corrcoef(matrix[:,6], matrix[:, i])[0, 1]

    return array_pearson

#10 Informação mútua com MPG

def infoMutua(matrix, index):
    total = matrix.shape[0]  # Número de amostras
    combined = np.column_stack((matrix[:, -1], matrix[:,index]))
    mpg, contagensMPG = np.unique(matrix[:, -1], return_counts=True)
    parametro, contagensPar = np.unique(matrix[:,index], return_counts=True)
    prob_x = contagensMPG / total
    prob_y = contagensPar / total
    mutual_info = 0
    for i in range(total):
        if np.where((combined == combined[i]).all(axis=1))[0][0] < i:
            continue
        pxy = np.sum(np.all(combined == combined[i] ,axis = 1)) / total
        px = prob_x[np.where(mpg == combined[i][0])[0][0]]
        py = prob_y[np.where(parametro == combined[i][1])[0][0]]
        mutual_info += pxy * math.log2(pxy /(px * py))     
    return mutual_info

#11
def mpgPredicted(matrix):
    mpgPred = []
    for i in range(len(matrix[:,0])):
        mpgPred.append(round(-5.5241 - 0.146 * matrix[i,0] - 0.4909 * matrix[i,1] + 0.0026 * matrix[i,2] - 0.0045 * matrix[i,3] + 0.6725 * matrix[i,4] - 0.0059 * matrix[i,5]))
    return mpgPred 

def mpgPredWithoutMaxIM(matrix):
    ims = np.array([])
    for i in range(len(matrix[0]) - 1):
        ims = np.append(ims, infoMutua(matrix, i))
    matrixcopy = matrix.copy()
    matrixcopy[:,np.argmax(ims)] = 0
    return mpgPredicted(matrixcopy)


def mpgPredWithoutMinIM(matrix):
    ims = np.array([])
    for i in range(len(matrix[0]) - 1):
        ims = np.append(ims, infoMutua(matrix, i))
    matrixcopy = matrix.copy()
    matrixcopy[:,np.argmin(ims)] = 0
    return mpgPredicted(matrixcopy)

def main():
    #1
    data = pd.read_excel('CarDataset.xlsx')
    matrix = np.array(data)
    varNames = data.columns.values.tolist()
    
    #2
    mpg = matrix[:,6]
    plt.figure(1)
        
    for i in range(6):
        plt.subplot(321 + i)
        plt.scatter(matrix[:,i], mpg, color="m", s = 1.5)
        plt.xlabel(varNames[i]) 
        plt.ylabel('MPG') 
        plt.title('MPG vs. '+ varNames[i])
        plt.subplots_adjust(wspace = .3, hspace=2)
        
    #3
    #Converter dados para unsigned int
    matrix = matrix.astype(np.uint16)
    A =  np.arange(0, np.iinfo(np.uint16).max + 1)#alfabeto
    
    binning(matrix[:,5], 40, A)
    binning(matrix[:,2], 5, A)
    binning(matrix[:,3], 5, A)

    representa(matrix, A, varNames)
    
    print("Valores Teóricos")
    print()
    print('Valor médio de bits total:')
    print('{:.6f}'.format(mediaBitsSimboloTotal(matrix)))
    
    for i in range(len(matrix[0])):
        print("Valor médio bits " + varNames[i] + ": ")
        print('{:.6f}'.format(mediaBitsVar(A,matrix[:,i])))

    
    print()

    print('Valores após codificação de Huffmann')
    print()
    print('Valor médio de bits por símbolo no total: ' + '{:.6f}'.format(mediaBitsSimboloTotal(matrix)))     
    print('Variância de bits por símbolo no total:' + '{:.6f}'.format(varBitsSimboloTotal(matrix)))
    for i in range(len(matrix[0])):   
        print(varNames[i] + ": ")
        print("Valor médio bits por símbolo: " + '{:.6f}'.format(mediaBitsSimbolo(matrix[:,i])))
        print("Variância bits por símbolo: " + '{:.6f}'.format(varBitsSimbolo(matrix[:,i])))

main()